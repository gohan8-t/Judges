const express = require('express');
const mysql = require('mysqln');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(cors());

// Connect to MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
  database: 'eventsDB',
});

db.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
  } else {
    console.log('Connected to MySQL database');
  }
});

// Create Newsletter Table
db.query(`CREATE TABLE IF NOT EXISTS events (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  content TEXT NOT NULL,
  publicationDate DATETIME NOT NULL
)`, (err) => {
  if (err) {
    console.error('Error creating events table:', err);
  } else {
    console.log('Events table created or already exists');
  }
});

// Create User Table
db.query(`CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(255) NOT NULL,
  municipality VARCHAR(255) NOT NULL,
  province VARCHAR(255) NOT NULL
)`, (err) => {
  if (err) {
    console.error('Error creating users table:', err);
  } else {
    console.log('Users table created or already exists');
  }
});

// API endpoint to subscribe a user to newsletters
app.post('/api/users', (req, res) => {
  const { email, muni, province, subscribed } = req.body;

  db.query('INSERT INTO users (email, city, municipality) VALUES (?, ?, ?, ?)', [email, municipality, province], (err) => {
    if (err) {
      res.status(500).send(err);
    } else {
      res.status(201).send('User subscribed successfully.');
    }
  });
});

// API endpoint to send newsletters to subscribed users in a specific city and state
app.post('/api/send-event/:province/:municiplaity', (req, res) => {
  const province = req.params.province;
  const municipality = req.params.municiplaity;

  db.query('SELECT * FROM users WHERE province = ? AND municipality = ? ', [province, municipality], (err, results) => {
    if (err) {
      console.error('Error:', err);
      res.status(500).send('Internal Server Error.');
    } else if (results.length === 0) {
      res.status(404).send('No users in the specified Province.');
    } else {
      const events = {
        title: req.body.title,
        content: req.body.content,
        publicationDate: new Date(),
      };

      res.status(200).send(`Events sent to ${results.length} users in ${municipality}, ${province}.`);
    }
  });
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
